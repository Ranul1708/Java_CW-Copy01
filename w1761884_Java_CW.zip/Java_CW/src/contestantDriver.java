public class contestantDriver {
    private car contestentTeam;
    private int position;

    public contestantDriver(car contestantTeam, int position){
        this.contestentTeam=contestantTeam;
        this.position=position;
    }
    public car getContestentTeam(){
        return this.contestentTeam;
    }
    public int getPosition(){
        return this.getPosition();
    }
}
