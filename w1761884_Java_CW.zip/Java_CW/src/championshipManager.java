
/*
* holds the abstract methods for formula01ChampionshipManagerClass
* */
public interface championshipManager{

    void addDriver();
    void deleteDriver();
    void deleteTeam();
    void addDriverExistingTeam();

    void menu();


}
