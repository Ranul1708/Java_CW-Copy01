import java.io.*;

public class main {
    public static void main(String[] args) {
        System.out.println("The program started");
        formula01ChampionshipManager manager = new formula01ChampionshipManager();
        manager.menu();
    }
}
